# Separate Customer and Owner Experiences for NivasPay

A comprehensive architecture to separate the NivasPay platform into two distinct, purpose-built user experiences—**NivasPay Homes** (Customer Experience) and **NivasPay Owner** (Owner Operations Portal)—linked through the **Hero Landing Page** as the primary junction comprising the **Customer Route** and the **Owner Route**, while sharing the existing secure backend, RBAC, and data model.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The Hero Landing Page is the central entry point and cleanly routes users into either the **Customer Route** or the **Owner Route**. Once entered, each experience operates as its own dedicated application with its own layout, navigation, and authentication screens. Neither experience displays the developer-style cross-app switcher tabs.

- **Confirmed Decision 1: Hero Landing Page as the Primary Junction**:
  - **Customer Route (`#/customer` / `onSelectToRent`)**: Opens the dedicated Customer experience. Unauthenticated users can search and inspect properties freely with zero barriers. Account-specific actions (applying, saving properties, viewing leases) prompt the dedicated customer auth screen.
  - **Owner Route (`#/owner` / `onSelectListProperty`)**: Opens the dedicated Owner experience. Unauthenticated users see the branded Owner authentication screen. Authenticated customers without owner permissions enter the Owner Onboarding flow. Authenticated owners enter their operations dashboard directly.
- **Confirmed Decision 2: Eradicate Developer-Style Top Switcher**:
  - Remove the persistent `[Home] [To Rent (Explore)] [List Property (Owner)] [Admin Console]` switcher from both the Customer and Owner interfaces.
  - In their place, provide a clean, single-element brand mark with an intuitive "Return to Home / NivasPay" exit affordance in each layout.
- **Confirmed Decision 3: Shared Identity & Role-Based Capabilities**:
  - A single user account can hold customer capabilities, owner capabilities, or both.
  - Existing customers onboarding as owners complete an authorized verification process (`backendService.upgradeCustomerToOwner`) without creating redundant accounts or losing tenant history.
- **Confirmed Decision 4: Protected Admin Isolation**:
  - Admin Console remains protected via cryptographic RBAC at `#/admin`. No public links are displayed on the landing page or standard headers.

---

## 1. Overview & Core Concept

### What It Does
NivasPay divides cleanly into two specialized, domain-tailored experiences linked by the Hero Landing Page:

```
                                  ┌───────────────────────────┐
                                  │     HERO LANDING PAGE     │
                                  │  (Central Decision Hub)   │
                                  └─────────────┬─────────────┘
                                                │
                 ┌──────────────────────────────┴──────────────────────────────┐
                 ▼                                                             ▼
     ┌───────────────────────┐                                     ┌───────────────────────┐
     │    CUSTOMER ROUTE     │                                     │      OWNER ROUTE      │
     │      (#/customer)     │                                     │       (#/owner)       │
     ├───────────────────────┤                                     ├───────────────────────┤
     │ • Focus: Renting      │                                     │ • Focus: Managing     │
     │ • Public Discovery    │                                     │ • Operations Cockpit  │
     │ • 360° Panoramas      │                                     │ • Unit Management     │
     │ • Saved Properties    │                                     │ • Tenant Screening    │
     │ • Rental Agreements   │                                     │ • Payout Ledger       │
     │ • Customer Auth UI    │                                     │ • Owner Auth & Onboard│
     │ • Return to Home      │                                     │ • Return to Home      │
     └───────────────────────┘                                     └───────────────────────┘
```

---

## 2. User Experience & Visual Design

### Customer Experience (NivasPay Homes)
- **Visual Feel**: Welcoming, consumer-friendly, warm off-white canvas (`#fbfaf7`), high-resolution property imagery, clean typographic filters.
- **Header & Navigation**:
  - Left: NivasPay Homes wordmark with "Tenant Portal" subtitle.
  - Center: Single-line navigation links (`Explore`, `Applications`, `My Rentals`, `Saved`).
  - Right: Language toggle (English/Hindi), User Profile / Sign In button, and an elegant "Return to Home" button.
- **Authentication**: Dedicated customer modal/screen with warm, tenant-focused copy ("Sign in to apply and reserve homes") and Google Sign-In support.

### Owner Experience (NivasPay Owner Portal)
- **Visual Feel**: Professional, high-density operations center, dark navy/slate sidebar (`#0f172a`), crisp white data surfaces with hairline borders (`#e2e8f0`), tabular numerals for financial figures.
- **Header & Sidebar**:
  - Sidebar: Operational navigation (`Dashboard Overview`, `Properties & Units`, `+ Add Property`, `Applications`, `Tenants & Leases`, `Financial Ledger`, `Reviews & Ratings`, `Settings`).
  - Header: Operational greeting, date breadcrumb, quick action buttons (`+ Add Property`, `View Applications`), owner profile pill, and "Return to Home" button.
- **Authentication & Onboarding**:
  - Unauthenticated view: Branded landlord auth screen ("Welcome to NivasPay Owner - Manage your properties & connect with prospective tenants").
  - Customer-to-Owner onboarding: Step-by-step form validating legal name, phone, PAN, and Fair Tenancy agreement before assigning owner capabilities on the backend.

---

## 3. Technical Architecture & Routing Strategy

### URL & State Synchronization
- **Primary Routes**:
  - `#/` or `#landing` -> Hero Landing Page
  - `#/customer` -> Customer Experience
  - `#/owner` -> Owner Experience
  - `#/admin` -> Admin Console (strictly authenticated)
- **Routing Engine in `App.tsx`**:
  - Listens to `window.location.hash` and synchronizes `activeSection` (`'landing' | 'customer_app' | 'owner_app' | 'admin_console'`).
  - When user clicks "TO RENT" on the Hero Landing Page: sets hash to `#/customer` and navigates smoothly.
  - When user clicks "LIST YOUR PROPERTY" on the Hero Landing Page: sets hash to `#/owner`.
  - Back/Forward browser navigation works seamlessly.
  - Stored preference in `sessionStorage` remembers the last visited view for reload convenience, but never bypasses role checks.

### Role & Identity Model in `backendService.ts`
- **Method `upgradeCustomerToOwner(userId, details)`**:
  - Validates user exists and is authenticated.
  - Checks required fields: full legal name, valid phone, PAN.
  - Creates an `OwnerProfile` linked to `userId`.
  - Updates user role to `'owner'` (or preserves dual capability).
  - Logs cryptographic audit entry `AUTH_UPGRADE_TO_OWNER_SUCCESS`.
  - Returns updated `SafeUser` and session.

---

## 4. Implementation Steps

1. **Step 1: Top-Level Routing & Layout Separation in `App.tsx`**:
   - Remove the developer-style switcher header `[Home] [To Rent] [List Property] [Admin]`.
   - Implement hash-based URL routing (`#customer`, `#owner`, `#landing`, `#admin`).
   - Cleanly isolate `HeroLandingPage`, `CustomerLayout`, `OwnerLayout`, and `AdminConsole`.
2. **Step 2: Customer Layout (`CustomerLayout.tsx`)**:
   - Encapsulate `CustomerApp` inside a dedicated layout with its own header, navigation, and "Return to Home" button.
   - Dedicated customer auth trigger with tenant-focused copy.
3. **Step 3: Owner Layout (`OwnerLayout.tsx`)**:
   - Encapsulate `OwnerApp` inside a dedicated layout with its own operational header, sidebar, and "Return to Home" button.
   - Integrate `OwnerAuthView` for unauthenticated visitors and `OwnerOnboardingView` for authenticated customers transitioning to owners.
4. **Step 4: Backend Role Transition in `backendService.ts`**:
   - Add `upgradeCustomerToOwner` to enable seamless capability addition.
5. **Step 5: Testing & Verification**:
   - Verify `npm test` passes (all 27 unit + 5 integration tests).
   - Test both routes from the Hero Landing page and verify independent navigation and exit paths.
