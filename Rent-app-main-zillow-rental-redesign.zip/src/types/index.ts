// Types for NivasPay Rental Platform (India)
// Compliant with DPDP Act 2023, RBI Payment Aggregator Guidelines, and Indian Fair Housing Standards

export type PrimaryRole = 'customer' | 'owner' | 'admin';
export type BrokerMembershipRole = 'broker_admin' | 'broker_staff' | 'BROKER_ADMIN' | 'BROKER_STAFF';
export type StaffMembershipRole = 'nivaspay_rm' | 'operations_manager' | 'NIVASPAY_RM' | 'OPERATIONS_MANAGER';
export type DelegatedAccessRole = BrokerMembershipRole | StaffMembershipRole;
export type UserRole = PrimaryRole | DelegatedAccessRole;
export type MembershipStatus = 'active' | 'suspended' | 'revoked' | 'ACTIVE' | 'SUSPENDED' | 'REVOKED';

export interface BrokerMembership {
  id: string;
  userId: string;
  agencyId: string;
  membershipRole: BrokerMembershipRole;
  permissions: string[];
  status: MembershipStatus;
  createdAt: string;
  updatedAt?: string;
}

export interface StaffMembership {
  id: string;
  userId: string;
  staffRole: StaffMembershipRole;
  assignedRegion: string;
  status: MembershipStatus;
  permissions: string[];
  createdAt: string;
  updatedAt?: string;
}

export type GenderType = 'Male' | 'Female' | 'Non-binary' | 'Prefer not to say';

export type SuitableForType = 'Anyone' | 'Men' | 'Women' | 'Families' | 'Working professionals';

export type RejectionReasonCode =
  | 'pets'
  | 'family_size'
  | 'occupation'
  | 'budget_deposit_mismatch'
  | 'incomplete_profile'
  | 'other';

export type AccountStatus = 'active' | 'suspended' | 'disabled';

export interface User {
  id: string;
  email: string;
  phone: string; // Stored masked in API response e.g. +91 98*** **412
  phoneEncrypted: string;
  passwordHash: string; // Salted PBKDF2-SHA256
  passwordSalt: string; // Cryptographic 16-byte random salt (hex)
  role: PrimaryRole;
  status: AccountStatus;
  failedLoginAttempts: number;
  lockoutUntil?: string;
  passwordResetTokenHash?: string;
  passwordResetExpiresAt?: string;
  brokerMembership?: BrokerMembership;
  staffMembership?: StaffMembership;
  createdAt: string;
  lastLoginAt?: string;
}

export interface SafeUser {
  id: string;
  email: string;
  phoneMasked: string;
  role: PrimaryRole;
  status: AccountStatus;
  name: string;
  brokerMembership?: BrokerMembership;
  staffMembership?: StaffMembership;
  createdAt: string;
  lastLoginAt?: string;
}

export interface AuthSession {
  token: string;
  userId: string;
  userEmail: string;
  role: UserRole;
  createdAt: string;
  expiresAt: string;
  isValid: boolean;
}

export interface RateLimitResult {
  allowed: boolean;
  currentRequests: number;
  maxRequests: number;
  windowSeconds: number;
  remaining: number;
  retryAfterSeconds: number;
  resetAt: number;
  ruleKey?: string;
}

export interface AuthResult {
  success: boolean;
  session?: AuthSession;
  user?: SafeUser;
  error?: string;
  lockoutRemainingSeconds?: number;
  rateLimited?: boolean;
  retryAfterSeconds?: number;
}

export interface CustomerSignupData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  phone?: string;
  agreedTerms: boolean;
}

export interface OwnerSignupData {
  fullName: string;
  email: string;
  password: string;
  confirmPassword: string;
  phone: string;
  agreedTerms: boolean;
  agreedAntiDiscrimination: boolean;
}

export interface CustomerProfile {
  id: string;
  userId: string;
  name: string;
  age: number; // Must be >= 18 under DPDP Act 2023 Section 9
  gender: GenderType;
  occupation: string;
  maritalStatus: 'Single' | 'Married' | 'Prefer not to say';
  familySize: number;
  hasPets: boolean;
  petType?: string;
  
  // High-Risk Sensitive Fields under DPDP Act 2023
  religion?: string; // Blank by default
  tribe?: string;    // Blank by default
  consentShareReligionTribe: boolean; // Unchecked by default!
  religionTribeConsentTimestamp?: string;
  religionTribeRetentionUntil?: string;

  // General DPDP Consent
  agreedDpdpNoticeAt: string;
  dpdpNoticeVersion: string;
  languagePreference: 'en' | 'hi';
}

export interface OwnerProfile {
  id: string;
  userId: string;
  fullName: string;
  phoneMasked: string;
  phoneEncrypted: string;
  
  // KYC details (through compliant Indian provider e.g. Setu / DigiLocker / Karza)
  panMasked: string; // e.g. ABCDE****F
  panEncrypted: string;
  panVerified: boolean;
  aadhaarMasked: string; // e.g. **** **** 8821
  aadhaarEncrypted: string;
  aadhaarVerified: boolean;
  kycVerifiedAt?: string;

  // Razorpay Route Linked Account for automated vendor settlements
  razorpayAccountId?: string;
  bankAccountMasked?: string;

  // Anti-discrimination compliance
  agreedAntiDiscriminationTermsAt: string;
  strikesCount: number;
  isSuspended: boolean;
  suspensionReason?: string;
}

export interface ListingRequirements {
  petsAllowed: boolean;
  allowedPetTypes?: string[];
  maxOccupants: number;
  vegOnly: boolean;
  smokingAllowed: boolean;
  minStayMonths: number;
  preferredOccupation?: string;
}
export type PropertyCategory = 'housing' | 'commercial';

export type ResidentialCategory =
  | 'APARTMENT'
  | 'INDEPENDENT_HOUSE'
  | 'VILLA'
  | 'PG'
  | 'HOSTEL'
  | 'SHARED_ROOM';

export type HousingCategoryType = ResidentialCategory;

export const RESIDENTIAL_CATEGORY_DISPLAY: Record<ResidentialCategory, string> = {
  APARTMENT: 'Apartments & Flats',
  INDEPENDENT_HOUSE: 'Independent Houses',
  VILLA: 'Villas',
  PG: 'PG Accommodation',
  HOSTEL: 'Hostels',
  SHARED_ROOM: 'Shared Rooms',
};

export const RESIDENTIAL_CATEGORIES: ResidentialCategory[] = [
  'APARTMENT',
  'INDEPENDENT_HOUSE',
  'VILLA',
  'PG',
  'HOSTEL',
  'SHARED_ROOM',
];

export type CommercialCategoryType =
  | 'OFFICE'
  | 'SHOP_SHOWROOM'
  | 'WAREHOUSE'
  | 'INDUSTRIAL'
  | 'COWORKING'
  | 'CLINIC'
  | 'OTHER_COMMERCIAL';

export type RoomType =
  | 'SINGLE'
  | 'PRIVATE_ROOM'
  | 'DOUBLE_SHARING'
  | 'TRIPLE_SHARING'
  | 'FOUR_SHARING'
  | 'DORMITORY';

export type BedType = 'SINGLE' | 'BUNK_LOWER' | 'BUNK_UPPER';
export type BedStatus = 'AVAILABLE' | 'RESERVED' | 'OCCUPIED' | 'MAINTENANCE' | 'UNAVAILABLE';
export type DietaryPolicy = 'VEG_ONLY' | 'NON_VEG_ALLOWED' | 'JAIN_AVAILABLE' | 'ANY';
export type GenderPreference = 'MALE_ONLY' | 'FEMALE_ONLY' | 'CO_ED' | 'ALL';

export interface BedInventoryItem {
  id: string;
  roomId: string;
  propertyId: string;
  bedNumber: string;
  bedType: BedType;
  rentMonthly: number;
  securityDeposit: number;
  status: BedStatus;
  tenantId?: string;
  version: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface PropertyRoom {
  id: string;
  propertyId: string;
  roomNumber: string;
  roomType: RoomType;
  totalBeds: number;
  occupiedBeds: number;
  rentPerBed: number;
  securityDeposit: number;
  attachedBathroom: boolean;
  hasBalcony: boolean;
  airConditioning: boolean;
  status: 'AVAILABLE' | 'FULL' | 'MAINTENANCE';
  beds?: BedInventoryItem[];
  createdAt?: string;
  updatedAt?: string;
}

export interface PgHostelMetadata {
  id?: string;
  propertyId: string;
  foodIncluded: boolean;
  mealOfferings: string[];
  dietaryPolicy: DietaryPolicy;
  genderPreference: GenderPreference;
  curfewTime?: string;
  noticePeriodDays: number;
  gateClosingTime?: string;
  wardenContactName?: string;
  wardenContactPhone?: string;
  visitorPolicy?: string;
  guestRestrictions?: string;
  smokingPolicy?: string;
  minStayMonths?: number;
  commonFacilities: string[];
  rulesAndRegulations: string[];
  createdAt?: string;
  updatedAt?: string;
}

export type UnitStatus = 'occupied' | 'available' | 'maintenance' | 'reserved' | 'AVAILABLE' | 'OCCUPIED' | 'RESERVED' | 'MAINTENANCE';

export interface PropertyUnit {
  id: string;
  propertyId?: string;
  unitNumber: string;
  unitType?: string;
  floor?: number;
  floorNumber?: number;
  bhk?: string;
  bedrooms?: number;
  bathrooms?: number;
  status: UnitStatus;
  availabilityStatus?: UnitStatus;
  rentMonthly?: number;
  securityDeposit?: number;
  furnishingStatus?: string;
  carpetAreaSqft?: number;
  maintenanceNotes?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Listing {
  id: string;
  ownerId: string;
  title: string;
  bhk: '1 RK' | '1 BHK' | '2 BHK' | '3 BHK' | '4+ BHK' | string;
  propertyType: 'Apartment' | 'Independent House' | 'Gated Villa' | 'Studio' | string;
  category: ResidentialCategory;
  locality: string;
  city: 'Itanagar' | 'Naharlagun' | 'Pasighat' | 'Ziro' | 'Tawang' | 'Roing' | string;
  
  // Public Approximate Pin (Exact door & street masked)
  approximateLat: number;
  approximateLng: number;
  approximateRadiusMeters: number; // e.g. 800m
  
  // Encrypted full address (Field-level encryption AES-256-GCM)
  // Masked in API response unless tenant's security deposit is confirmed!
  fullAddressEncrypted: string;
  maskedAddressPreview: string; // e.g. "Near Ganga Lake viewpoint corridor, Chandranagar, Itanagar (Full address unlocked post-deposit)"

  rentMonthly: number;
  securityDeposit: number;
  bedrooms?: number;
  bathrooms?: number;
  sqft?: number;
  parking?: number;
  isFeatured?: boolean;
  amenities: string[];
  photos: string[];
  suitableFor: SuitableForType; // Publicly displayed
  requirements: ListingRequirements;
  
  status:
    | 'draft'
    | 'pending_verification'
    | 'published'
    | 'available'
    | 'application_received'
    | 'reserved'
    | 'rented'
    | 'unavailable'
    | 'suspended'
    | 'active'
    | 'paused';
  totalUnits?: number;
  occupiedUnits?: number;
  unitNumber?: string;
  units?: PropertyUnit[];
  rooms?: PropertyRoom[];
  beds?: BedInventoryItem[];
  pgHostelMetadata?: PgHostelMetadata;
  occupancyHistory?: PropertyOccupancyDataPoint[];
  createdAt: string;
}

export interface PGAccommodation extends Listing {
  category: 'PG';
  rooms?: PropertyRoom[];
  pgHostelMetadata?: PgHostelMetadata;
}

export interface Hostel extends Listing {
  category: 'HOSTEL';
  rooms?: PropertyRoom[];
  beds?: BedInventoryItem[];
  pgHostelMetadata?: PgHostelMetadata;
}

export interface PropertyOccupancyDataPoint {
  month: string;
  shortMonth: string;
  occupiedUnits: number;
  totalUnits: number;
  occupancyRate: number;
  estimatedRevenue?: number;
}

export interface Application {
  id: string;
  listingId: string;
  customerId: string;
  status:
    | 'pending'
    | 'accepted'
    | 'rejected'
    | 'enquiry'
    | 'viewing_scheduled'
    | 'under_review'
    | 'approved'
    | 'payment_required'
    | 'payment_completed'
    | 'agreement_pending'
    | 'agreement_completed'
    | 'active_tenancy'
    | 'completed'
    | 'cancelled';
  
  // Viewing details
  viewingDate?: string;
  viewingTimeSlot?: string;
  viewingConfirmed?: boolean;

  // Financial status (₹20 Non-Refundable Application Fee)
  applicationFeePaid: boolean;
  applicationFeeAmount: number; // ₹20 Non-Refundable Application Fee
  applicationFeePaymentId?: string;
  
  // Rejection handling (Non-refundable ₹20 fee)
  rejectedReasonCode?: RejectionReasonCode;
  rejectedReasonExplanation?: string;
  refundInitiated?: boolean;
  refundAmount?: number;
  platformRetainedFee?: number;
  refundPaymentId?: string;

  // Acceptance, 10% Brokerage & Security Deposit settlement
  brokerageAmount?: number; // 10% of monthly rent upon acceptance
  brokeragePaid?: boolean;
  brokeragePaymentId?: string;
  depositCreditAmount?: number; // Zero - application fee does not convert to deposit
  depositBalancePaid?: boolean;
  depositBalancePaymentId?: string;
  depositBalanceAmount?: number; // Full security deposit
  gstInvoiceNumber?: string;
  commissionAmountOwner?: number; // Legacy alias for ownerPlatformFee (0 for standard tenancies; owners pay 0 brokerage)
  ownerPlatformFee?: number; // Validly configured owner platform fee (default 0; owners never pay brokerage)

  // Active Tenancy & Agreement
  agreementId?: string;
  tenancyStartDate?: string;
  nextRentDueDate?: string;

  // Notification Status (Transparency & Provider Tracking)
  notificationStatus?: ApplicationNotificationStatus;

  // Audit
  ownerViewedSensitiveFieldsAt?: string;
  createdAt: string;
  updatedAt: string;
}

export type NotificationChannelDeliveryStatus =
  | 'NOT_CONFIGURED'
  | 'SIMULATED'
  | 'QUEUED'
  | 'SENT'
  | 'DELIVERED'
  | 'FAILED';

export interface ApplicationNotificationStatus {
  inAppStatus: 'RECORDED' | 'NOT_CONFIGURED' | 'FAILED';
  emailStatus: NotificationChannelDeliveryStatus;
  smsStatus: NotificationChannelDeliveryStatus;
  overallStatus: NotificationChannelDeliveryStatus;
  emailDelivered: boolean;
  smsDelivered: boolean;
  dispatchedAt?: string;
  notes?: string;
}

export type PaymentType =
  | 'booking_fee'
  | 'security_deposit'
  | 'rent_payment'
  | 'brokerage'
  | 'platform_fee'
  | 'owner_platform_fee'
  | 'maintenance_charge'
  | 'application_fee'
  | 'auto_refund'
  | 'deposit_balance'
  | 'owner_payout'
  | 'platform_commission'
  | 'dispute_refund';

export type PaymentStatus =
  | 'Pending'
  | 'Processing'
  | 'Successful'
  | 'Failed'
  | 'Cancelled'
  | 'Refunded'
  | 'Partially Refunded'
  | 'Disputed'
  | 'captured'
  | 'settled'
  | 'refunded'
  | 'failed'
  | 'success';

export interface PaymentRecord {
  id: string;
  applicationId?: string;
  propertyId?: string;
  propertyName?: string;
  payerId: string;
  payeeId: string;
  amount: number;
  currency: 'INR';
  type: PaymentType;
  method: 'upi' | 'card' | 'netbanking';
  upiVpa?: string;
  gateway: 'razorpay_route' | 'razorpay_standard' | 'upi_direct';
  idempotencyKey: string;
  status: PaymentStatus;
  razorpayPaymentId: string;
  razorpaySignatureVerified: boolean;
  gstInvoiceNo?: string;
  gstAmount?: number;
  platformFee?: number;
  description: string;
  failureReason?: string;
  refundStatus?: 'None' | 'Requested' | 'Approved' | 'Processing' | 'Completed' | 'Rejected';
  refundAmount?: number;
  refundReason?: string;
  refundDate?: string;
  refundReference?: string;
  createdAt: string;
}

export interface RefundRecord {
  id: string;
  transactionId: string;
  applicationId?: string;
  userId: string;
  userName: string;
  amount: number;
  reason: string;
  status: 'Refund Requested' | 'Refund Approved' | 'Refund Processing' | 'Refund Completed' | 'Refund Rejected';
  requestedAt: string;
  resolvedAt?: string;
  referenceId: string;
  adminNotes?: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'application' | 'payment' | 'refund' | 'viewing' | 'agreement' | 'security';
  isRead: boolean;
  createdAt: string;
  linkAction?: string;
}

export interface RentalAgreement {
  id: string;
  applicationId: string;
  listingId: string;
  propertyTitle: string;
  propertyAddress: string;
  tenantId: string;
  tenantName: string;
  ownerId: string;
  ownerName: string;
  monthlyRent: number;
  securityDeposit: number;
  commencementDate: string;
  tenancyPeriodMonths: number;
  status: 'draft' | 'pending_signatures' | 'active' | 'terminated' | 'concluded';
  tenantSignedAt?: string;
  ownerSignedAt?: string;
  concludedAt?: string;
  contractHash: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId: string;
  propertyId?: string;
  text: string;
  createdAt: string;
  isRead: boolean;
}

export interface ConsentLog {
  id: string;
  userId: string;
  consentType: 'dpdp_terms' | 'sensitive_religion_tribe' | 'profile_sharing' | 'withdrawal';
  granted: boolean;
  version: string;
  ipAddress: string;
  timestamp: string;
  purpose: string;
  retentionPeriod: string;
}

export interface RejectionReport {
  id: string;
  applicationId: string;
  customerId: string;
  reportedOwnerId: string;
  allegationDescription: string;
  rejectionReasonGiven?: string;
  status: 'Reviewed' | 'Action Taken' | 'pending_review' | 'strike_issued' | 'owner_suspended' | 'dismissed';
  adminNotes?: string;
  createdAt: string;
  resolvedAt?: string;
}

export interface AuditLog {
  id: string;
  actorId: string;
  actorRole: UserRole | 'system';
  action:
    | 'VIEW_SENSITIVE_FIELDS'
    | 'REJECT_APPLICATION'
    | 'ACCEPT_APPLICATION'
    | 'WITHDRAW_CONSENT'
    | 'ERASURE_REQUEST'
    | 'UNAUTHORIZED_IDOR_ATTEMPT'
    | 'PAYMENT_CAPTURE'
    | 'DEPOSIT_CONFIRMED_ADDRESS_UNLOCKED'
    | 'UPDATE_REPORT_STATUS'
    | 'PROCESS_RENT_PAYMENT'
    | 'REQUEST_REFUND'
    | 'UPDATE_REFUND_STATUS'
    | 'AUTH_LOGIN_SUCCESS'
    | 'AUTH_LOGIN_FAILED'
    | 'AUTH_LOGOUT'
    | 'AUTH_CROSS_ROLE_LOGIN_BLOCKED'
    | 'AUTH_SIGNUP_CUSTOMER_SUCCESS'
    | 'AUTH_SIGNUP_OWNER_SUCCESS'
    | 'AUTH_PASSWORD_RESET_REQUESTED'
    | 'AUTH_PASSWORD_RESET_SUCCESS'
    | string;
  targetEntity: string;
  targetId: string;
  metadata?: Record<string, any>;
  ipAddress: string;
  timestamp: string;
}

export interface GrievanceOfficerInfo {
  name: string;
  designation: string;
  address: string;
  email: string;
  phone: string;
  responseSlaHours: number;
}

export interface ActionRequiredItem {
  id: string;
  title: string;
  description: string;
  category: 'applications' | 'decisions' | 'vacant' | 'rent' | 'property';
  actionLabel: string;
  actionTarget: 'applications' | 'properties' | 'rent_payments' | 'listings';
  urgency: 'high' | 'medium' | 'low';
}

export interface VacantUnitItem {
  propertyId: string;
  propertyTitle: string;
  location: string;
  unitNumber: string;
  bhk: string;
  monthlyRent: number;
  availableSinceDays: number;
  securityDeposit: number;
}

export interface OwnerKPIs {
  propertiesCount: number;
  totalUnits: number;
  occupiedUnits: number;
  vacantUnits: number;
  occupancyRate: number;
  applicationsCount: number;
}

export interface OwnerOccupancyData {
  totalUnits: number;
  occupiedUnits: number;
  vacantUnits: number;
  percentage: number;
}

export interface OwnerFinancialData {
  grossRentDue: number;
  thisMonthDue: number;
  rentCollected: number;
  thisMonthCollected: number;
  pendingRent: number;
  thisMonthPending: number;
  collectionRate: number;
  lastMonthCollected: number;
  ownerBrokerage: 0; // Property owners do NOT pay brokerage; UI displays "Owner Brokerage: None"
  ownerCharges: number;
  ownerPlatformCharges: number;
  taxesWithholding: number;
  transactionCharges: number;
  netOwnerSettlement: number;
  netSettlementMonth: number;
  averageMonthlyRentPerUnit: number;
  settlementStatus: 'Settled' | 'Pending Settlement' | 'Processing' | 'Failed';
  settlementStatement?: OwnerSettlementStatement;
  historicalMonthly: Array<{
    month: string;
    shortMonth?: string;
    collected: number;
    pending: number;
    expectedRent?: number;
    collectionRate?: number;
  }>;
}

/**
 * Authoritative Owner Settlement Statement produced strictly by backendService.
 * Guarantees that rental income excludes all platform-side revenue.
 */
export interface OwnerSettlementStatement {
  ownerId: string;
  billingMonth: string;
  grossRentDue: number;
  grossRentCollected: number;
  rentalIncome: number; // Strictly rent_payment only, excludes customer brokerage and application fees
  ownerBrokerage: 0; // Strictly 0: No brokerage charged to owners
  ownerCharges: number; // Configured platform fee + transaction charges
  ownerPlatformCharges: number;
  transactionCharges: number;
  taxesWithholding: number;
  netOwnerSettlement: number; // Final server-calculated Net Owner Settlement value
  settlementStatus: 'Settled' | 'Pending Settlement' | 'Processing' | 'Failed';
  settlementAccount: string;
  payoutMethod: 'Razorpay Route (Direct Settlement)' | 'NEFT' | 'IMPS';
  validation: {
    customerBrokerageExcluded: number;
    applicationFeesExcluded: number;
    platformFeesExcluded: number;
    isRentalIncomePure: boolean;
  };
}

/**
 * Server-authoritative rental payment accounting breakdown.
 * Enforces strict architectural separation between customer payment,
 * NivasPay platform revenue, owner rental income, and net settlement.
 */
export interface RentalPaymentAccountingBreakdown {
  customerPaymentAmount: number;
  ownerGrossRentAmount: number;
  nivasPayBrokerageRevenue: number; // 10% of 1 month's rent (customer-side only)
  ownerPlatformFee: number; // 0 unless validly configured in system
  transactionCharges: number;
  gstAmount: number; // 0 (GST calculations removed)
  tdsAmount: number; // 0 (TDS calculations removed)
  refundAdjustmentAmount: number;
  netAmountSettledToOwner: number; // ownerGrossRentAmount - ownerPlatformFee - transactionCharges
  settlementStatus: 'Settled' | 'Pending Settlement' | 'Processing' | 'Failed';
  payoutMethod: 'Razorpay Route (Direct Settlement)' | 'NEFT' | 'IMPS';
}

export interface OwnerApplicationsSummary {
  total: number;
  new: number;
  underReview: number;
  accepted: number;
  rejected: number;
  withdrawn: number;
  conversionRate?: number;
}

export interface OwnerOperationalMetrics {
  ownerId: string;
  kpis: OwnerKPIs;
  occupancy: OwnerOccupancyData;
  financials: OwnerFinancialData;
  applicationsSummary: OwnerApplicationsSummary;
  actionRequired: ActionRequiredItem[];
  vacantUnits: VacantUnitItem[];
  properties: Listing[];
}

export interface PlatformSettings {
  commissionRatePct: number;
  responseTimeLimitHours: number;
  applicationFeeAmount: number;
  customerBrokeragePct: number;
  ownerBrokeragePct: number;
  autoRefundWindowHours: number;
  maxOwnerStrikes: number;
  maintenanceMode: boolean;
  updatedAt: string;
  updatedBy: string;
}

// =========================================================================
// TENANT REVIEWS, RATINGS & MODERATION SYSTEM
// =========================================================================
export type ReviewModerationStatus = 'pending_moderation' | 'approved' | 'flagged' | 'rejected';

export interface PropertyReview {
  id: string;
  agreementId: string;
  listingId: string;
  propertyId?: string; // Convenient alias for listingId
  propertyTitle: string;
  propertyLocality?: string;
  propertyCity?: string;
  unitNumber?: string;
  tenantId: string;
  tenantName: string;
  ownerId: string;
  ownerName: string;

  // Star Ratings (1-5 integer scale)
  propertyRating: number; // 1 to 5
  ownerRating: number; // 1 to 5
  overallRating: number; // Average of property & owner rating or overall composite (1.0 to 5.0)

  // Sub-category ratings (1-5)
  maintenanceRating?: number;
  cleanlinessRating?: number;
  communicationRating?: number;
  depositReturnRating?: number;
  categoryRatings?: {
    cleanliness?: number;
    maintenance?: number;
    communication?: number;
    depositReturn?: number;
  };

  // Text Review
  title: string;
  reviewText: string;
  tags?: string[]; // e.g. ["Smooth Deposit Return", "Quiet Neighborhood", "Prompt Maintenance", "Great Landlord"]

  // Tenancy metadata
  commencementDate?: string;
  concludedDate?: string;
  tenancyStartDate?: string;
  tenancyEndDate?: string;
  stayDurationMonths?: number;

  // Inappropriate Content Moderation System
  moderationStatus: ReviewModerationStatus;
  flaggedReason?: string;
  autoModerated?: boolean;
  moderatedBy?: string;
  moderatedAt?: string;
  moderationNotes?: string;

  // Owner Response
  ownerResponse?: string;
  ownerRespondedAt?: string;
  ownerResponseAt?: string;

  createdAt: string;
  updatedAt?: string;
}

export interface CreateReviewInput {
  agreementId: string;
  propertyRating: number;
  ownerRating: number;
  title: string;
  reviewText: string;
  maintenanceRating?: number;
  cleanlinessRating?: number;
  communicationRating?: number;
  depositReturnRating?: number;
  tags?: string[];
}

export interface OwnerReviewSummary {
  ownerId: string;
  totalReviews: number;
  averageOwnerRating: number;
  averagePropertyRating: number;
  overallRating: number;
  distribution: {
    5: number;
    4: number;
    3: number;
    2: number;
    1: number;
  };
  ratingDistribution: {
    5: number;
    4: number;
    3: number;
    2: number;
    1: number;
  };
  cleanlinessAverage: number;
  maintenanceAverage: number;
  communicationAverage: number;
  categoryAverages: {
    cleanliness?: number;
    maintenance?: number;
    communication?: number;
    depositReturn?: number;
  };
}

// ============================================================================
// RBAC Supporting Interfaces: Broker, Agency, RM, Operations
// ============================================================================

export interface Agency {
  id: string;
  name: string;
  licenseNumber: string;
  reraNumber: string;
  contactEmail: string;
  contactPhone: string;
  address: string;
  city: string;
  adminUserId: string;
  isVerified: boolean;
  commissionRatePercent: number;
  totalDealsClosed: number;
  createdAt: string;
}

export interface AgencyStaffMember {
  id: string;
  agencyId: string;
  userId: string;
  name: string;
  email: string;
  phone: string;
  role: 'broker_staff';
  assignedListingsCount: number;
  activeLeadsCount: number;
  createdAt: string;
}

export type PropertyAuthorizationStatus = 'PENDING' | 'VERIFIED' | 'REJECTED' | 'EXPIRED';

export interface PropertyAuthorization {
  id: string;
  propertyId: string;
  ownerId: string;
  agencyId: string;
  agencyName: string;
  authorizationType: 'EXCLUSIVE' | 'NON_EXCLUSIVE';
  docReference: string;
  status: PropertyAuthorizationStatus;
  verifiedBy?: string;
  verifiedAt?: string;
  validUntil: string;
  createdAt: string;
}

export type BrokerLeadStatus = 'NEW' | 'CONTACTED' | 'VISIT_SCHEDULED' | 'CONVERTED' | 'CLOSED';

export interface BrokerLead {
  id: string;
  agencyId: string;
  assignedStaffId?: string;
  assignedStaffName?: string;
  propertyId: string;
  propertyTitle: string;
  customerName: string;
  customerPhoneMasked: string;
  customerEmail: string;
  requirement: string;
  status: BrokerLeadStatus;
  scheduledVisitDate?: string;
  notes?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface RmInteractionNote {
  id: string;
  authorId: string;
  authorName: string;
  note: string;
  timestamp: string;
}

export interface RmAssignment {
  id: string;
  rmUserId: string;
  rmName: string;
  customerUserId: string;
  customerName: string;
  customerPhoneMasked: string;
  customerEmail: string;
  customerRequirement: string;
  budgetMonthly: number;
  preferredCity: string;
  status: 'ACTIVE' | 'VISIT_COORDINATED' | 'COMPLETED' | 'ESCALATED';
  notes: RmInteractionNote[];
  assignedAt: string;
  lastFollowUpAt?: string;
}

export type OperationalCaseType =
  | 'DISPUTE'
  | 'KYC_VERIFICATION'
  | 'LISTING_AUTHORIZATION'
  | 'REFUND_REQUEST'
  | 'SLA_BREACH';

export type OperationalCasePriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type OperationalCaseStatus = 'OPEN' | 'IN_REVIEW' | 'ESCALATED' | 'RESOLVED';

export interface OperationalCase {
  id: string;
  caseType: OperationalCaseType;
  title: string;
  priority: OperationalCasePriority;
  status: OperationalCaseStatus;
  assignedTo: string;
  assignedToName: string;
  entityId?: string;
  details: string;
  resolutionNotes?: string;
  createdAt: string;
  resolvedAt?: string;
}



