// Human-readable date and time formatters for NivasPay
// Formats ISO timestamps into relative expressions (e.g., 'Applied 2 days ago', 'Just now')

/**
 * Converts an ISO 8601 date string or Date object into a relative time string.
 * Supports customizable prefix (default: 'Applied').
 *
 * Examples:
 * - 'Applied just now'
 * - 'Applied 5 minutes ago'
 * - 'Applied 2 hours ago'
 * - 'Applied yesterday'
 * - 'Applied 2 days ago'
 * - 'Applied 2 weeks ago'
 * - 'Applied 1 month ago'
 *
 * @param isoDate - ISO date string or Date object
 * @param prefix - Prefix to prepend (e.g. 'Applied', 'Created', 'Submitted', or '' for none)
 * @param referenceTime - Optional reference time for testing/deterministic calculations (default: Date.now())
 */
export function formatRelativeTime(
  isoDate: string | Date | undefined | null,
  prefix: string = 'Applied',
  referenceTime?: number | Date
): string {
  if (!isoDate) {
    return prefix ? `${prefix} recently` : 'Recently';
  }

  const date = typeof isoDate === 'string' ? new Date(isoDate) : isoDate;
  if (isNaN(date.getTime())) {
    return prefix ? `${prefix} recently` : 'Recently';
  }

  const now = referenceTime
    ? typeof referenceTime === 'number'
      ? referenceTime
      : referenceTime.getTime()
    : Date.now();

  const diffMs = now - date.getTime();

  // If date is slightly in the future (due to minor clock skew), treat as "just now"
  if (diffMs < 0 && Math.abs(diffMs) < 60 * 1000) {
    return prefix ? `${prefix} just now` : 'Just now';
  }

  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHours = Math.floor(diffMin / 60);
  const diffDays = Math.floor(diffHours / 24);
  const diffWeeks = Math.floor(diffDays / 7);
  const diffMonths = Math.floor(diffDays / 30);
  const diffYears = Math.floor(diffDays / 365);

  let relativeString: string;

  if (diffSec < 45) {
    relativeString = 'just now';
  } else if (diffSec < 90) {
    relativeString = '1 minute ago';
  } else if (diffMin < 60) {
    relativeString = `${diffMin} minutes ago`;
  } else if (diffHours === 1) {
    relativeString = '1 hour ago';
  } else if (diffHours < 24) {
    relativeString = `${diffHours} hours ago`;
  } else if (diffDays === 1) {
    relativeString = 'yesterday';
  } else if (diffDays < 7) {
    relativeString = `${diffDays} days ago`;
  } else if (diffWeeks === 1) {
    relativeString = '1 week ago';
  } else if (diffWeeks < 4) {
    relativeString = `${diffWeeks} weeks ago`;
  } else if (diffMonths === 1) {
    relativeString = '1 month ago';
  } else if (diffMonths < 12) {
    relativeString = `${diffMonths} months ago`;
  } else if (diffYears === 1) {
    relativeString = '1 year ago';
  } else {
    relativeString = `${diffYears} years ago`;
  }

  if (!prefix || prefix.trim().length === 0) {
    // Capitalize first character if no prefix
    return relativeString.charAt(0).toUpperCase() + relativeString.slice(1);
  }

  return `${prefix.trim()} ${relativeString}`;
}

/**
 * Formats an ISO date into a localized absolute date string (e.g. '01 Oct 2026, 09:30 AM')
 */
export function formatAbsoluteDate(
  isoDate: string | Date | undefined | null,
  includeTime: boolean = true
): string {
  if (!isoDate) return '';
  const date = typeof isoDate === 'string' ? new Date(isoDate) : isoDate;
  if (isNaN(date.getTime())) return '';

  const options: Intl.DateTimeFormatOptions = {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    ...(includeTime
      ? {
          hour: '2-digit',
          minute: '2-digit',
          hour12: true,
        }
      : {}),
  };

  return new Intl.DateTimeFormat('en-IN', options).format(date);
}

/**
 * Returns an object containing both relative and absolute representations
 * Ideal for rendering human text with tooltip hover support
 */
export function formatApplicationDate(
  isoDate: string | Date | undefined | null,
  prefix: string = 'Applied'
): { relative: string; absolute: string } {
  return {
    relative: formatRelativeTime(isoDate, prefix),
    absolute: formatAbsoluteDate(isoDate, true),
  };
}
