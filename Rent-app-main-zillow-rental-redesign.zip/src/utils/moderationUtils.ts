/**
 * Content Moderation Engine for NivasPay Property and Owner Reviews
 * Enforces community guidelines, safeguards against abusive language, hate speech,
 * profanity, harassment, spam, and personal identifiable information (PII) leakage.
 */

// Common profanity, offensive, abusive terms in English and Hindi/Hinglish
const PROFANITY_PATTERNS = [
  // English vulgarities / insults
  /\b(fuck|shit|bitch|bastard|asshole|cunt|dick|pussy|whore|slut|idiot|scumbag|scammer)\b/i,
  /\b(scam|fraudster|cheat|thief|criminal)\b/i, // defamation without grievance process
  // Hindi / Hinglish derogatory terms
  /\b(chutiya|bhenchod|madarchod|harami|kamina|gandu|kutta|saala|randi|bhosadi|launda)\b/i,
  // Hate speech & discrimination triggers
  /\b(casteist|racist|terrorist|jihadi)\b/i,
];

// PII & Spam patterns: 10-digit phone numbers, emails, external links
const PHONE_PATTERN = /\b(?:\+?91[\s-]?)?[6789]\d{9}\b/;
const EMAIL_PATTERN = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/;
const URL_PATTERN = /\b(https?:\/\/|www\.)\S+\b/i;

export interface ModerationCheckResult {
  isClean: boolean;
  recommendedStatus: 'approved' | 'flagged';
  flaggedReason?: string;
  violations: string[];
}

/**
 * Evaluates review text and title against community safety & moderation rules.
 */
export function checkReviewContent(title: string, reviewText: string): ModerationCheckResult {
  const combined = `${title} ${reviewText}`;
  const violations: string[] = [];

  // 1. Check for Profanity and Abusive Language
  for (const pattern of PROFANITY_PATTERNS) {
    const match = combined.match(pattern);
    if (match) {
      violations.push(`Inappropriate or abusive language detected ("${match[0]}")`);
      break;
    }
  }

  // 2. Check for PII: Phone numbers
  if (PHONE_PATTERN.test(combined)) {
    violations.push('Direct phone numbers or contact details are not permitted in public reviews');
  }

  // 3. Check for PII: Email addresses
  if (EMAIL_PATTERN.test(combined)) {
    violations.push('Email addresses are prohibited in public reviews for privacy protection');
  }

  // 4. Check for Promotional Links / URLs
  if (URL_PATTERN.test(combined)) {
    violations.push('External URLs or links are prohibited');
  }

  // 5. Excessive Aggression / All Caps screaming
  const alphabeticChars = combined.replace(/[^A-Za-z]/g, '');
  if (alphabeticChars.length > 25) {
    const uppercaseCount = (combined.match(/[A-Z]/g) || []).length;
    if (uppercaseCount / alphabeticChars.length > 0.85) {
      violations.push('Excessive uppercase text flagged for editorial review');
    }
  }

  const isClean = violations.length === 0;

  return {
    isClean,
    recommendedStatus: isClean ? 'approved' : 'flagged',
    flaggedReason: isClean ? undefined : violations.join('; '),
    violations,
  };
}
